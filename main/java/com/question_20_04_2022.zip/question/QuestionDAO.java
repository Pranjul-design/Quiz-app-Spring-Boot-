package com.question;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface QuestionDAO extends JpaRepository<QuestionBean, Integer> {
	
	public List<QuestionBean> findByQuestionId(int id);
	public List<QuestionBean> findBySubjectIdOrderByQuestionIdDesc(int id);
	public QuestionBean findByQuestionIdOrderByQuestionIdDesc(int queId);
	public List<QuestionBean> findByStatusOrderByQuestionIdDesc(int status);
	public List<QuestionBean> findByQueStatusAndStatusOrderByQuestionIdAsc(int queStatus,int status);
	public List<QuestionBean> findByQueStatusAndStatusAndSubjectIdOrderByQuestionIdAsc(int queStatus,int status,int subId);
}
